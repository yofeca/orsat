<?php
include_once(dirname(__FILE__)."/database.php");

function pre($a){
	echo "<pre>";
	print_r($a);
	echo "</pre>";
}
function parseTXO($filepath){ //filepath should be absolute path of the file
	$csv = array_map('str_getcsv', file($filepath));
	$tcsv = count($csv);
	
	//pre($csv);
	//exit();
	$header_counter = 0;
	
	$filename = basename($filepath);
	
	$sql = "select * from `txo_dumps` where `filename`='".mysql_real_escape_string($filename)."'";
	
	$r = dbQuery($sql);
	
	if(!isset($r[0])){
		//headers
		for($i=1; $i<$tcsv; $i++){
			$header_counter++;
			
			$t = count($csv[$i]);
			$key = "";
			$value = "";

			for($j=0; $j<$t; $j++){
				$index = trim($csv[$i][$j]);
				if(substr($index, -5, 5) != "====="){
					
					if(substr($index, -1, 1)==":"){
						$value = "";
						$key = trim(trim($csv[$i][$j]), ":");
						//get the values
						for($k=($j+1); $k<$t; $k++){
							$index = trim($csv[$i][$k]);
							if(!(substr($index, -1, 1)==":")){
								$value .= trim($csv[$i][$k])." ";
							}
							else{
								$k=$t;
							}
						}
						$sqlext[] = "`".trim($key)."` = '".mysql_real_escape_string(trim($value))."'";
					}
				}else{
					break 2;
				}
			}
		}//end of header loop

		//get the year of the file
		$file_date = explode("=",$sqlext[1]);
		$dt = date_parse($file_date[1]);
		$file_year = $dt['year'];
		
		$sql = "insert into `txo_dumps` set
			`fn_id` = '".mysql_real_escape_string($file_year.trim($filename))."',
			`filename`='".mysql_real_escape_string($filename)."', 
			`dateadded`=NOW(),
			".implode(", ", $sqlext);
		
		$sql = str_replace(", `` = ''","",$sql); //removes unnecessary columns ex. `` = ''
		
		$r = dbQuery($sql);
		$insert_id = $r['mysql_insert_id'];
		$txo_id = $insert_id;
		
		//column values (PLOT A / PLOT B)
		for($i=$header_counter+6; $i<$tcsv; $i++){
			
			$subtcsv_count = count($csv[$i]);
			
			if($subtcsv_count > 4 && (trim($csv[$i][0]) || trim($csv[$i][1]))){
				$sql = "insert into `column_values` set
				`fn_id` = '".mysql_real_escape_string($file_year.trim($filename))."',
				`filename` = '".mysql_real_escape_string(trim($filename))."',
				`Peak` = '".mysql_real_escape_string(trim($csv[$i][0]))."',
				`Component` = '".mysql_real_escape_string(trim($csv[$i][1]))."',
				`Amount` = '".mysql_real_escape_string(trim($csv[$i][2]))."',
				`Time` = '".mysql_real_escape_string(trim($csv[$i][3]))."',
				`Area` = '".mysql_real_escape_string(trim($csv[$i][4]))."',";
				
				if(isset($csv[$i][5])){
					$sql .= "`Method RT` = '".mysql_real_escape_string(trim($csv[$i][5]))."',";
				}
				
				$sql .= "`txo_id` = '".$txo_id."',`dateadded` = NOW()";
				$r = dbQuery($sql);
				$insert_id = $r['mysql_insert_id'];
			}else{ 
				//store the total values
				if( $subtcsv_count > 4 ){
					if($csv[$i][2] == "------" && $csv[$i][4] == "------"){
						$sql = "insert into `txo_tvalues` set
							`fn_id` = '".mysql_real_escape_string($file_year.trim($filename))."',
							`filename` = '".mysql_real_escape_string(trim($filename))."',
							`pp_carbon` = '".mysql_real_escape_string(trim($csv[$i+1][2]))."',
							`area` = '".mysql_real_escape_string(trim($csv[$i+1][4]))."',";
						
						if(isset($csv[$i][5])){
							$sql .= "`method_rt` = '".mysql_real_escape_string(trim($csv[$i+1][5]))."',";
						}
						
						$sql .= "`txo_id` = '" . $txo_id . "', `ascii_file` = '" . mysql_real_escape_string(trim($csv[$tcsv-1][1])). "', `dateadded` = NOW()";
						$r = dbQuery($sql);
						break;
					}
				}
			}
		} //end of plot loop
		$sql = "UPDATE `files` SET status='1' WHERE file='" . $filename . "'";
		$r = dbQuery($sql);
		return true;
	} //end of dQuery();
	return false;
}
/*
function get_files($path) {
	$dir_list = array_diff( scanDIR( $path ), array( '..' , '.' ) );
	
	if( $dir_list ) {
		
		natsort( $dir_list ); //naturally sort volume names
		
		$sorted_list = array();
		
		foreach( $dir_list as $dl ){
			array_push( $sorted_list, $dl );
		}
		
		return $sorted_list;
		
	} else {
		exit( "\nError! Missing Txo.\n" );
	}
	
}
*/

function get_files(){
	//$sql = "SELECT file FROM `files` WHERE `status`='0'";
	//$sql = "SELECT file FROM `files` WHERE `status`='0' LIMIT 1";
	$sql = "SELECT file FROM `files` WHERE `status`='0' LIMIT 500";
	$r = dbQuery($sql);

	return $r;
	//return $r[0]['file'];
}
$path = str_replace('orsat_parser', '', dirname(__FILE__) ). "/orsat/dumps";
//$p = get_files($path);

$p = get_files();

if($p){ //check if there are files not processed
	for($i=count($p)-1; $i>=0; $i--){
		if(parseTXO($path."/".$p[$i]['file'])){
		//if(parseTXO($path."/".$p)){
			echo "TXO File Successfully Imported!\n";
		}
		else{
			echo "TXO File Import Failed!\n";
		}
	}
}
?>